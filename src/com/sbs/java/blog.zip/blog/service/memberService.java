package com.sbs.java.blog.service;

public class memberService {

}
