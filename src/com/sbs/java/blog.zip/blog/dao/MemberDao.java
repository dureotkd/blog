package com.sbs.java.blog.dao;

import java.sql.Connection;

import com.sbs.java.blog.util.DBUtil;
import com.sbs.java.blog.util.SecSql;

public class MemberDao {
	private Connection dbConn;
	
	public MemberDao(Connection dbConn) {
		this.dbConn = dbConn;
	}

	public int doActionDojoin(String name,String nickname,String loginId,String loginPw,String email) {

		SecSql secSql = new SecSql();
		// 모르겟음.
		secSql.append("INSERT INTO member ");
		secSql.append("SET regDate = NOW() ");
		secSql.append(", name = ? ", name);
		secSql.append(", nickname = ? ",nickname);
		secSql.append(", loginId = ? ",loginId);
		secSql.append(", loginPw = ? ",loginPw);
		secSql.append(", email = ? ",email);
		
		return DBUtil.insert(dbConn, secSql);
	}

	public boolean isLoginIdJoinable(String loginId) {
		SecSql secSql = new SecSql();
		
		secSql.append("SELECT COUNT(*) from member ");
		secSql.append("WHERE loginId = ? ",loginId);
		String sql = "";
		//전체 행 갯수 가져오기 COUNT(*) 쿼리
		// and loginPw = '%s' 
		return DBUtil.selectRowIntValue(dbConn, secSql) == 0;
	}

	public boolean isLoginConfirm(String loginId, String loginPw) {
		SecSql secSql = new SecSql();
		
		secSql.append("SELECT COUNT(*) from member ");
		secSql.append("WHERE loginId = ? ",loginId);
		secSql.append("and loginPw = ? ",loginPw);
		
		//전체 행 갯수 가져오기 COUNT(*) 쿼리
		// and loginPw = '%s' 
		return DBUtil.selectRowIntValue(dbConn, secSql) == 0;
	}


}
