package com.sbs.java.blog.dao;

public abstract class Dao {

}