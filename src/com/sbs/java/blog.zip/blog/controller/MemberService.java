package com.sbs.java.blog.controller;

import java.sql.Connection;

import com.sbs.java.blog.dao.MemberDao;
import com.sbs.java.blog.service.Service;

public class MemberService extends Service {

	private MemberDao memberDao;
	
	public MemberService(Connection dbConn) {
		memberDao = new MemberDao(dbConn);
	}
	public int doActionDojoin(String name,String nickname,String loginId,String loginPw, String email) {
		return memberDao.doActionDojoin(name,nickname,loginId,loginPw,email);
	}
	public boolean isLoginIdJoinable(String loginId) {
		return memberDao.isLoginIdJoinable(loginId);
	}
	public boolean isLoginConfirm(String loginId, String loginPw) {
		return memberDao.isLoginConfirm(loginId,loginPw);
	}
}
