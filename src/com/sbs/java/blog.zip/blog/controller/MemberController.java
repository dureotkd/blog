package com.sbs.java.blog.controller;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbs.java.blog.service.ArticleService;
import com.sbs.java.blog.service.memberService;

public class MemberController extends Controller {

	public MemberController(Connection dbConn, String actionMethodName, HttpServletRequest req,
			HttpServletResponse resp) {
		super(dbConn, actionMethodName, req, resp);
	}

	public String doAction() {
		// 스위치문 case 주고
		switch(actionMethodName) {
		case "join":
			return doActionJoin(req,resp);
		case "doJoin":
			return doActionDojoin(req,resp);
		case "doLogin":
			return doActionLogin(req,resp);
		case "login":
			return doActiondoLogin(req,resp);
		}
		return "";
	}
	private String doActionLogin(HttpServletRequest req, HttpServletResponse resp) {
		String loginId = req.getParameter("loginId");
		String loginPw = req.getParameter("loginPw");
		
		if ( loginId.isEmpty()) {
			return "html:<script> alert('아이디를 입력해주세요.'); location.replace('login'); </script>";
		}
		else if ( loginPw.isEmpty()) {
			return "html:<script> alert('비밀번호를 입력해주세요.'); location.replace('login'); </script>";
		}
		boolean isLoginConfirm = memberService.isLoginConfirm(loginId,loginPw);
		
		
		if ( isLoginConfirm == true  ) {
			return "html:<script> alert('회원정보가 일치하지 않습니다.'); location.replace('login'); </script>";
		}
		
		return "html:<script> alert('로그인 되었습니다.'); location.replace('login'); </script>";
	}

	private String doActiondoLogin(HttpServletRequest req, HttpServletResponse resp) {
		return "member/login.jsp";
	}

	private String doActionDojoin(HttpServletRequest req, HttpServletResponse resp) {
		String name = req.getParameter("name");
		String nickname = req.getParameter("nickname");
		String loginId = req.getParameter("loginId");
		String loginPw = req.getParameter("loginPw");
		String email = req.getParameter("email");
		String loginPwConfirm = req.getParameter("loginPwConfirm");
		
		boolean isLoginIdJoinable = memberService.isLoginIdJoinable(loginId);
		// isLoginIdJoinable == false면 중복 아이디 
		if (isLoginIdJoinable == false ) {
			return "html:<script> alert('중복된 아이디입니다.'); location.replace('join'); </script>";
		} else {
			System.out.println("중복 x 테스트");
		}
		
		int memberId = memberService.doActionDojoin(name,nickname,loginId,loginPw,email);
		return "html:<script> alert(' " + nickname + "님 회원이 되신걸 환영합니다.'); location.replace('join'); </script>";
		
	}

	private String doActionJoin(HttpServletRequest req, HttpServletResponse resp) {
		// 이거실행
		return "member/join.jsp";
	}
	
	
		
}